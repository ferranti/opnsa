Hello! We are #OpNSA

This is a pack of flyers you can print out and use for paperstorms or other events. Feel free to modify them anyway you'd like or completely make your own and rip off ideas.

These work best in 8.5x11 standard paper or anything with similar ratio except for the business cards.

If you have an idea for a flyer, but lack the design skill. Please drop by our IRC channel here: https://webchat.anonops.com/?channels=opNsa - and give us your suggestions!

There are three folders, one is the "General Flyers" folder which contains flyers designed specially to be read by people who are completely clueless about what is going on. These are the main ones you want to use to put on cars, posts, etc which will be viewed by general people.

Another folder is the "Others". These are generally more detailed which contain more content which are best used in places like newsboards in coffee shops.

And finally the "Business Cards" folder which includes small 2x3.5 designs with minimal info. You can print these at any print shop for quite cheap. Ideally for passing around as they have a bigger chance of not being thrown away.


=== Where to Print? ===

You can choose to print these yourself or just go to any print shop that does copies. Make sure to make them black and white if you're going to do this as they are much cheaper. Color prints usually go for about 40-60 cents per page when black and white can be from 8-10 cents per page. 

Remember to pay in cash when doing this to avoid a paper trail!

================



Good luck. Stay safe.

-OpNSA


www.OpNSA.com